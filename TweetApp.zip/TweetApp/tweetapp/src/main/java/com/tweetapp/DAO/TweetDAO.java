package com.tweetapp.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import com.tweetapp.DBConnection;
import com.tweetapp.bean.Tweet;
import com.tweetapp.bean.User;

public class TweetDAO {

	
	
	// Inserting new user in Database

	
	public boolean insertUser(User user) {
		// TODO Auto-generated method stub
		boolean result = false;
		try
		{
			String sql = "Insert into user VALUES(?, ?, ?, ?, ?, ?)";
			Connection connection = DBConnection.getConnection();
			
			PreparedStatement stmt = connection.prepareStatement(sql);
			
			stmt.setString(1, user.getFirst_name());
			stmt.setString(2, user.getLast_name());
			stmt.setString(3, user.getGender());
			stmt.setString(4, user.getEmail());
			stmt.setString(5, user.getDob());
			stmt.setString(6, user.getPassword());
			
			int inserted = stmt.executeUpdate();
			
			result = inserted >=1;
			DBConnection.disconnect(connection);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	// Update or reset password
	
	public boolean updateUser(User user) {
		// TODO Auto-generated method stub
		boolean result = false;
		
		try {
			
			String sql = "UPDATE user set password=? where email=?";
			Connection conn = DBConnection.getConnection();
			
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, user.getPassword());
			stmt.setString(2, user.getEmail());
			
			int updated = stmt.executeUpdate();
			result = updated >=1;
			DBConnection.disconnect(conn);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return result;	
		}
	
	// Retrieving all details of the user through email

	public User getUser(String email) {
		// TODO Auto-generated method stub
		User user = null;
		
		try {
			
			String sql = "SELECT * fROM user WHERE email=?";
			Connection conn = DBConnection.getConnection();
			
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, email);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				user = new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
			}
			DBConnection.disconnect(conn);
		}
		catch(Exception e){
			e.printStackTrace();
		}	
		
		
		return user;
	}
	
	// Validating the email and password for login

	public boolean validate(String email, String password) {
		// TODO Auto-generated method stub
		
		boolean result = false;
		

		try {
			
			String sql = "SELECT * fROM user WHERE email=? and password=?";
			Connection conn = DBConnection.getConnection();
			
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, email);
			stmt.setString(2, password);
			
			
			ResultSet rs = stmt.executeQuery();
		
		result = rs.next();
		}
		
		catch(Exception e){
			e.printStackTrace();
		}	
		
		
		return result;
	}

	
	//validating the email and check if the email already exists or not 
	
	public boolean validateemail(String email)
	
	{
	boolean result = false;
	

	try {
		
		String sql = "SELECT email fROM user WHERE email=?";
		Connection conn = DBConnection.getConnection();
		
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setString(1, email);
		
		
		ResultSet rs = stmt.executeQuery();
	
	result = rs.next();
	}
	
	catch(Exception e){
		e.printStackTrace();
	}	
	
	
	return result;
}

// Insertion of tweet in database along with the email
	
	public boolean inserttweet(Tweet tweet1) {
		// TODO Auto-generated method stub
		boolean result = false;
		try
		{
			String sql = "Insert into tweetdb VALUES(?, ?)";
			Connection connection = DBConnection.getConnection();
			
			PreparedStatement stmt = connection.prepareStatement(sql);
			
			stmt.setString(1, tweet1.getEmail());
			stmt.setString(2, tweet1.getTweet());
			
			int inserted = stmt.executeUpdate();
			
			result = inserted >=1;
			DBConnection.disconnect(connection);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	// Retrieving all the tweets for login email id
	
	public ArrayList<Tweet> getmyTweet(String email) {
		
		ArrayList<Tweet> tweets = new ArrayList<Tweet>();
		
Tweet tweet = null;
		
		try {
			
			String sql = "SELECT * fROM tweetdb Where email=? ";
			Connection conn = DBConnection.getConnection();
			
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, email);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				tweet = new Tweet(rs.getString(1), rs.getString(2));
				
				tweets.add(tweet);
			}
			DBConnection.disconnect(conn);
		}
		catch(Exception e){
			e.printStackTrace();
		}	
		
		
		return tweets;
		// TODO Auto-generated method stub
	}
	
	// Retrieving all the users email that have tweeted so far
	
	public HashSet<Tweet> viewuser() {
		// TODO Auto-generated method stub
		HashSet<Tweet> tweets = new HashSet<Tweet>();
		
		Tweet tweet = null;
				
				try {
					
					String sql = "SELECT * fROM tweetdb ";
					Connection conn = DBConnection.getConnection();
					
					PreparedStatement stmt = conn.prepareStatement(sql);
					
					
					ResultSet rs = stmt.executeQuery();
					
					while(rs.next()) {
						
						tweet = new Tweet(rs.getString(1), rs.getString(2));
						tweets.add(tweet);
//					
//					
//					Set<Tweet> s=new HashSet<Tweet>();
//					s.addAll(tweets);
//					tweets = new ArrayList<Tweet>();
//					tweets.addAll(s);
						
	//					tweets.add(rs.getString(1));
					}
					DBConnection.disconnect(conn);
				}
				catch(Exception e){
					e.printStackTrace();
				}	
				
				
				return tweets;
		
		
		
		
	}

	
	// Retriving all the details of the tweets and user email
	
	public ArrayList<Tweet> viewalltweetsanduser() {
		// TODO Auto-generated method stub
ArrayList<Tweet> tweets = new ArrayList<Tweet>();
		
		Tweet tweet = null;
				
				try {
					
					String sql = "SELECT * fROM tweetdb ";
					Connection conn = DBConnection.getConnection();
					
					PreparedStatement stmt = conn.prepareStatement(sql);
					
					
					ResultSet rs = stmt.executeQuery();
					
					while(rs.next()) {
						
						tweet = new Tweet(rs.getString(1), rs.getString(2));
						
						tweets.add(tweet);
					}
					DBConnection.disconnect(conn);
				}
				catch(Exception e){
					e.printStackTrace();
				}	
				
				
				return tweets;
		
	}
}
