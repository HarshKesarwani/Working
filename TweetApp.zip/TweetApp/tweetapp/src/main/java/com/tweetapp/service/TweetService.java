package com.tweetapp.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Scanner;


import com.tweetapp.Demo;
import com.tweetapp.DAO.TweetDAO;
import com.tweetapp.bean.Tweet;
import com.tweetapp.bean.User;

public class TweetService {
	
	Scanner scan = new Scanner(System.in);
	TweetDAO tweetdao = new TweetDAO();
	
	
	
	
	
	
	
	
	public void getregister()  // for new users
	{
		System.out.println("Enter your first_name");
		String first_name=scan.nextLine();
		System.out.println("Enter your last_name");
		String last_name=scan.nextLine();
		System.out.println("Enter your gender (Male, Female, Others)");
		String gender=scan.nextLine();
		System.out.println("Enter your email");
		String email=scan.nextLine();
		System.out.println("Enter your date of birth (dd/MM/yyyy)");
		String dob=scan.nextLine();
		System.out.println("Enter your password");
		String password=scan.nextLine();
		
		User user = new User(first_name, last_name,gender,email,dob,password);
		
		if(tweetdao.validateemail(email)) {
		
			System.out.println("Email --> " + email + " already exists " + "Please try different email id");
			System.out.println();
			Demo demo = new Demo();
			demo.check();
		}
		else {
			
			if(tweetdao.insertUser(user))
			{
			System.out.println("Registration successful. Please login now");
			System.out.println();
			Demo demo = new Demo();
			demo.check();
			
			}
		
			else {
			System.out.println("Wrong Entry. Please try again");
			System.out.println();
			Demo demo = new Demo();
			demo.check();
			}
		}
		
		
		
		
	}
	public void getlogin()  // for login purpose
	{
		System.out.println("Enter your email");
		String email = scan.nextLine();
		
		System.out.println("Enter your password");
		String password = scan.nextLine();
		
		if(email == null || password == null)
		{
			System.out.println("Email or password cannot be null, please try again");
			return;
			
		}
		
		if(tweetdao.validate(email,password)) {
			
			try
			{
			System.out.println("Login success");
			System.out.println();
			System.out.println("#################### LOGIN ##################");
			System.out.println("Enter your Choice");
			System.out.println(" 1. Post a tweet ");
			System.out.println(" 2. View my tweets ");
			System.out.println(" 3. View all tweets ");
			System.out.println(" 4. View all Users ");
			System.out.println(" 5. Reset my password ");
			System.out.println(" 6. Logout ");
			System.out.println("Your choice");
			int choice =scan.nextInt();
			
			switch(choice) {
			
			case 1:
				TweetService post = new TweetService();
				post.posttweet(email);
				
				break;
			
			case 2:
				TweetService viewtweet = new TweetService();
				 viewtweet.viewmytweet(email);
				
				break;
				
			case 3:
				TweetService viewall = new TweetService();
				viewall.viewalltweet();
				
				break;
				
			case 4:
				TweetService viewuser = new TweetService();
				viewuser.viewalluser();
				
				break;
				
			case 5:
				TweetService reset = new TweetService();
				reset.updatepassword();
				
				break;
				
			case 6:
				TweetService logout = new TweetService();
				logout.logoutapp();
				
				break;
				
				default: System.out.println("You have Entered a wrong choice");
			}
			}
		
			 catch(InputMismatchException ex ) {
		            System.out.println("Invalid or InputMismatch, Please try again");
		         
		           
		        }
			System.out.println();
			Demo demo = new Demo();
			demo.check();
		}	
			
			else {
				System.out.println("Login failed");
				System.out.println();
				Demo demo = new Demo();
				demo.check();
			}
		
	}
	
	
	
	private void logoutapp() {  // logout
		// TODO Auto-generated method stub
		
		System.out.println("You have successfully Logged out");
		System.out.println();
		Demo demo = new Demo();
		demo.check();
		
	}
	
	private void viewalluser() {  // fetching all the users that have tweeted
		// TODO Auto-generated method stub
		HashSet<Tweet> arry1 = tweetdao.viewuser();
		
		System.out.println(" Here are all the users " );
		for(Tweet t1 : arry1) 
			System.out.println(" ---> " + t1.getEmail());
//			String n=t1.getEmail();
//					 HashSet<String> set = new HashSet<String>(Arrays.asList(n));
//	
		
		
		
	}
	private void viewalltweet() {  // fetching all the tweets along with the users
		// TODO Auto-generated method stub
		
ArrayList<Tweet> arry1 = tweetdao.viewalltweetsanduser();
		
		System.out.println(" Here are all the users " );
		for(Tweet t2 : arry1)
			{System.out.println(" User --->  " + t2.getEmail());
		System.out.println(" Tweets ---> " + t2.getTweet());
		
			}
		
		
		
	}
	private void viewmytweet(String email) { //fetching all the tweets for the login user
		
		ArrayList<Tweet> arry = tweetdao.getmyTweet(email);
		
		System.out.println(" Here are your Tweets " + email);
		for(Tweet t : arry)
			System.out.println(" ---> " + t.getTweet());
		// TODO Auto-generated method stub	
	
	}
	public void posttweet(String email) { // for posting new tweets
		// TODO Auto-generated method stub
		
		System.out.println("Enter your Tweet");
		String tweet = scan.nextLine();
		
		if(tweet == null)
		{
			System.out.println("Tweets cannot be null");
			return;
		}
		
Tweet tweet1 = new Tweet(email, tweet);
		
		if(tweetdao.inserttweet(tweet1))
		{
			System.out.println("Your tweet is posted Sucessfully!!!");
			return;
		}
		
		else {
			System.out.println("Sorry!! your tweet cannot be posted. Try again");
			return;
		}
		
	}
	
	

	
	public void updatepassword() //forgot password
	{
		System.out.println("Enter your email ");
		String email = scan.nextLine();
		
		
		User user = tweetdao.getUser(email);
		
		if(user == null)
		{
			System.out.println("No such User exist with email:  "+ email);
			return;
			
		}
		
		System.out.println("Enter the new password");
		String password = scan.nextLine();
		
		user.setPassword(password);
		
		if(tweetdao.updateUser(user)) {
			System.out.println("Password has been updated!");
		} else {
			System.out.println("Password has not been updated");
		}
		
	}	

}
