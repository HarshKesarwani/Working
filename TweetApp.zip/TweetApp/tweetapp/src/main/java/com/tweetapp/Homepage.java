package com.tweetapp;

import java.util.Scanner;
import com.tweetapp.bean.User;
import com.tweetapp.service.*;

public class Homepage {

	public static void main(String args[]) 
	{
		
		Demo demo = new Demo();
		demo.check();
		
	
//		
//		Scanner scanner = new Scanner(System.in);
//		
//		System.out.println("Enter your choice");
//		System.out.println(" 1. Already a User? ");
//		System.out.println(" 2. New User? ");
//		System.out.println(" 3. Forgot password ");
//		System.out.println(" Enter your choice ");
//		int choice = scanner.nextInt();
//		
//		
//		switch(choice) {
//		
//		case 1:
//			TweetService login = new TweetService();
//			login.getlogin();
//			
//			break;
//			
//		case 2:
//			TweetService register = new TweetService();
//			register.getregister();
//			
//			break;
//			
//		case 3:
//			TweetService password = new TweetService();
//			password.updatepassword();
//			
//			break;
//		
//		default:System.out.println("Wrong choice");
//
//		
//		}
	}

	
	
}
