package com.tweetapp;


import java.util.InputMismatchException;
import java.util.Scanner;

import com.tweetapp.service.TweetService;

public class Demo {

	public void check() 
	{
		
	Scanner scanner = new Scanner(System.in);
//	System.out.println("################## TWEET APP ##################");
//	System.out.println("Enter your choice");
//	System.out.println(" 1. Already a User? ");
//	System.out.println(" 2. New User? ");
//	System.out.println(" 3. Forgot password ");
//	System.out.println("Your choice ");
//	int choice = scanner.nextInt();
	


	 
        try {
        	System.out.println("################## TWEET APP ##################");
        	System.out.println("Enter your choice");
        	System.out.println(" 1. Already a User? ");
        	System.out.println(" 2. New User? ");
        	System.out.println(" 3. Forgot password ");
        	System.out.println("Your choice ");
        	int choice = scanner.nextInt();   
        	   
	
        
	switch(choice) {
	
	case 1:
		TweetService login = new TweetService();
		login.getlogin();
		
		break;
		
	case 2:
		TweetService register = new TweetService();
		register.getregister();
		
		break;
		
	case 3:
		TweetService password = new TweetService();
		password.updatepassword();
		
		break;
	
	default: System.out.println("Wrong Choice, please try again");
	 
	
	}
        }
        catch(InputMismatchException ex ) {
            System.out.println("Invalid or InputMismatch, Please try again");
         
           
        }
	 }
	
	}
	

	
	

	
		
		
		
	
	

