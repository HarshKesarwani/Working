package com.tweetapp.bean;

public class Tweet {
	
	private String email;
	private String tweet;
	
	public Tweet() {}
	
	public Tweet(String email, String tweet) {
		this.email = email;
		this.tweet = tweet;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTweet() {
		return tweet;
	}

	public void setTweet(String tweet) {
		this.tweet = tweet;
	}

	@Override
	public String toString() {
		return "Tweet [email=" + email + ", tweet=" + tweet + "]";
	}
	
	
	
	

}
